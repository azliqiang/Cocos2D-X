#include "GameScene.h"
#include "GameOverScene.h"


USING_NS_CC;
using namespace CocosDenshion;

Scene* GameScene::createScene()
{
	// 	//创建物理世界的场景
	auto scene = Scene::createWithPhysics();
	//PhysicsWorld* phyWorld = scene->getPhysicsWorld();
	//phyWorld->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);
	// 'layer' is an autorelease object
	auto layer = GameScene::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}
bool GameScene::init()
{
	if ( !Layer::init() )
	{
		return false;
	}

	Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

	score = 0;		//初始化分数
	status = 1 ;		//初始化游戏状态
	//添加分数
	//auto label = Label::createWithTTF("","fonts/MarkerFelt.ttf", 24);  
	auto label = cocos2d::Label::createWithSystemFont("分数:0","Arial",24);
	label ->setTag(100); 
	label->setPosition(Vec2(0, origin.y + visibleSize.height - label->getContentSize().height/2));
	label->setHorizontalAlignment(kCCTextAlignmentRight);
	label->setAnchorPoint(Vec2(0,0.5));
    this->addChild(label, 1);

	//播放背景音乐
	SimpleAudioEngine::getInstance()->playBackgroundMusic("sounds/game_music.wav");
	//创建滚动背景
	//背景精灵
    auto bg1 = Sprite::create("background.png");
    bg1->setPosition(Vec2(origin.x + visibleSize.width/2,0));
	bg1->setAnchorPoint(Vec2(0.5,0));
	bg1->setTag(101);
    this->addChild(bg1,0);
    
	//第二张背景图，是跟在第一张的上面，无缝连接，两张图形成不间断的地图滚动 
    auto bg2 = Sprite::create("background.png");
	bg2->setPosition(Vec2(origin.x + visibleSize.width/2, bg1->getPositionY()+bg1->getContentSize().height));
	bg2->setAnchorPoint(Vec2(0.5,0));
	bg2->setTag(102);
    this->addChild(bg2,0);
	
	//背景滚动的定时器,0.01执行一次传入的函数
	this->schedule(schedule_selector(GameScene::backgroundMove),0.01); 


	//创建我机
	auto plane = Sprite::create("hero1.png");
	plane->setPosition(visibleSize.width/2+origin.x,200);
	plane->setTag(103);
	//设置碰撞属性
	//碰撞掩码，用于判断是否可以与其他物体碰撞，判断逻辑为两者的碰撞掩码进行逻辑与，如为零则不会碰撞，否则会
	//这里只有我机、敌机、子弹，子弹和敌机可以碰撞，敌机和我机可以碰撞，我机和子弹不可以碰撞，以次可以设置它们的掩码分别为0x01(0001)、0x03(0011)、0x02(0010)
	auto planeBody = PhysicsBody::createBox(plane->getContentSize());
	planeBody->setContactTestBitmask(0x0003);
	planeBody->setCategoryBitmask(0x0001);
	planeBody->setCollisionBitmask(0x0007);
	planeBody->setGravityEnable(false);
	plane->setPhysicsBody(planeBody);
	this->addChild(plane);

	Animation * animation = Animation::create();
	SpriteFrame * spriteFrame1 = SpriteFrame::create("hero1.png",Rect(0,0,102,126));
	SpriteFrame * spriteFrame2 = SpriteFrame::create("hero2.png",Rect(0,0,102,126));
	animation->addSpriteFrame(spriteFrame1);
	animation->addSpriteFrame(spriteFrame2);
	animation->setDelayPerUnit(0.15f);
	Animate * animate = Animate::create(animation);

	plane->runAction(RepeatForever::create(animate));
	
	//触摸事件注册，要通过回调函数来控制飞机的坐标
	setTouchEnabled(true);
	//设置为单点触碰
	setTouchMode(Touch::DispatchMode::ONE_BY_ONE);

	//我机发射子弹
	this->schedule(schedule_selector(GameScene::bulletCreate),0.3);
	//让子弹飞和让敌机飞
	this->schedule(schedule_selector(GameScene::objectMove),0.01);

	//敌机创建
	this->schedule(schedule_selector(GameScene::enemyCreate),0.5);
	/*
	//添加暂停按钮
	auto mpauseItem = MenuItemImage::create( "game_pause_nor.png", "game_pause_pressed.png", CC_CALLBACK_1(GameScene::gamePause, this));
	mpauseItem->setPosition(Vec2(visibleSize.width + origin.x - mpauseItem->getContentSize().width/2, visibleSize.height + origin.y - mpauseItem->getContentSize().height/2));
	//添加继续按钮
	auto mresumeItem = MenuItemImage::create( "game_resume_nor.png", "game_resume_pressed.png", CC_CALLBACK_1(GameScene::gameResume, this));
	mresumeItem->setPosition(Vec2(visibleSize.width/2 + origin.x - mresumeItem->getContentSize().width/2, visibleSize.height/2 + origin.y - mresumeItem->getContentSize().width/2));
	
	auto mcloseItem = MenuItemImage::create( "CloseNormal.png", "CloseSelected.png",CC_CALLBACK_1(GameScene::gameClose, this));
    mcloseItem->setPosition(Vec2(origin.x + visibleSize.width/2 + mcloseItem->getContentSize().width/2 ,visibleSize.height/2 + origin.y + mcloseItem->getContentSize().height/2));

	//把菜单项添加到菜单精灵中
	auto mmenu = Menu::create(mpauseItem,mresumeItem,mcloseItem, NULL);
    mmenu->setPosition(Vec2::ZERO);
	//把菜单精灵添加到当前的层中
    this->addChild(mmenu);
	*/
	return true;
}
//层进入的时候会调用该函数，进行物理世界的碰撞检测
void GameScene::onEnter()
{
	Layer::onEnter();

	auto listener = EventListenerPhysicsContact::create();
	
	listener -> onContactBegin = [=](PhysicsContact& contact)
	{
		auto spriteA = (Sprite *)contact.getShapeA()->getBody()->getNode();
		auto spriteB = (Sprite *)contact.getShapeB()->getBody()->getNode();
		int tag1 = spriteA->getTag();
		int tag2 = spriteB->getTag();
		Vec2 vec1 = spriteA->getPosition();
		Vec2 vec2 = spriteB->getPosition();
		//敌机和子弹碰撞碰撞
		if(tag1 + tag2 == 210 || tag1 + tag2 == 211)	//敌机105或104 子弹106 我机103
		{
			SimpleAudioEngine::getInstance()->playEffect("sounds/use_bomb.wav"); 
			//加分，如果是104则是小敌机500分，105是大敌机1000分
			if(tag1 == 104 || tag2 == 104)
			{
				score += 500;
			}
			else 
			{
				score += 1000;
			}
			auto scoreSpire = (Label *)this->getChildByTag(100);
			scoreSpire->setString(String::createWithFormat("分数:%d",score)->_string);
			//粒子特效
			auto * system = ParticleSystemQuad::create("particle_texture.plist"); 
			 
			if(tag1 == 104 || tag1 == 105)
			{
				//移除敌机和子弹
				enemyList.eraseObject(spriteA);
				bulletList.eraseObject(spriteB);
				system->setPosition(vec1);
				//启动动画
				this->planeBomb(vec1,tag1);
			} 
			else 
			{ 
				enemyList.eraseObject(spriteB);
				bulletList.eraseObject(spriteA); 
				//启动动画
				this->planeBomb(vec2,tag2);
				system->setPosition(vec2);
			}
			
			//粒子特效加入层中
			this->addChild(system);
			spriteA->removeFromParent();
			spriteB->removeFromParent();
		}
		//敌机与我机碰撞
		else if(tag1 + tag2 == 207 || tag1+tag2 == 208)
		{
			SimpleAudioEngine::getInstance()->playEffect("sounds/game_over.wav"); 
			//修改游戏状态为结束状态3
			status = 3;
			//停止所有的定时器
			stopAllSchedule();
			//游戏结束逻辑	
			if(tag1 == 103)
			{
				
				this->planeBomb(vec2,tag2);
				this->planeBomb(vec1,tag1);
			}
			else
			{
				this->planeBomb(vec1,tag1);
				this->planeBomb(vec2,tag2);
			}
			//使用UserDefault存储些用户数据分数，用法比较简单，map的使用方法，
			UserDefault * userDefault = UserDefault::getInstance();
			int topScore = userDefault->getIntegerForKey("topScore");
			if(topScore < score)
			{
				userDefault->setIntegerForKey("topScore",score);
			}
			else
				userDefault->setIntegerForKey("topScore",topScore);
			userDefault->setIntegerForKey("currentScore",score);
			
			spriteA->removeFromParent();
			spriteB->removeFromParent();
		}
		else{}

		return true;
	};

	//注册监听器
	EventDispatcher * eventDispatcher = Director::getInstance()->getEventDispatcher();
	eventDispatcher ->addEventListenerWithSceneGraphPriority(listener,this);

}
//暂停游戏
void GameScene::gamePause(Ref * pSender)
{
	
}
//继续游戏
void GameScene::gameResume(Ref * pSender)
{
	
}
//退出游戏
void GameScene::gameClose(Ref * pSender)
{
	
}
//背景滚动回调函数的实现
void GameScene::backgroundMove(float f)
{
	//背景滚动逻辑
	auto bg1 = this->getChildByTag(101);
	auto bg2 = this->getChildByTag(102);
	//当第二张图片退出屏幕时，把第一张图片设置到屏幕中，由于背景图片的高度是大于屏幕的高度的，所以判断逻辑要复杂点
	if(bg2 -> getPositionY() + bg2->getContentSize().height <= Director::getInstance()->getVisibleSize().height)
	{
		bg1->setPositionY(-bg1->getContentSize().height + Director::getInstance()->getVisibleSize().height);
	}
	bg1->setPositionY(bg1->getPositionY()-4);
	bg2->setPositionY(bg1->getPositionY()+bg1->getContentSize().height);
}
//手指点击下时，记录该点的位置，该点为起点
bool GameScene::onTouchBegan(Touch * touch, Event * event)
{
	if(status == 1)
	{
		fx=touch->getLocation().x;
		fy=touch->getLocation().y;
	}
	return true;
}
//每次移动把移动的位置（终点）记录下来，并与之前记录下的位置相减，得到飞机该位移的相对量（x、y轴移动多少）,并刷新起点位置
void GameScene::onTouchMoved(Touch * touch, Event * event)
{
	if(status == 1)
	{
		int mx=(touch->getLocation().x-fx);
		int my=(touch->getLocation().y-fy);
		auto spPlane=this->getChildByTag(103);
		spPlane->runAction(MoveBy::create(0,Point(mx,my)));
		fx=touch->getLocation().x;
		fy=touch->getLocation().y;
	}
}
//创建子弹
void GameScene::bulletCreate(float f)
{
	SimpleAudioEngine::getInstance()->playEffect("sounds/bullet.wav"); 
	auto plane=this->getChildByTag(103);
	Sprite * bullet=Sprite::create("bullet.png");
	bullet->setPosition(plane->getPosition().x,plane->getPosition().y+60);
	bullet->setTag(106);
	auto bulletBody = PhysicsBody::createBox(bullet->getContentSize());
	bulletBody->setContactTestBitmask(0x0002);
	bulletBody->setCategoryBitmask(0x0005);
	bulletBody->setCollisionBitmask(0x0002);
	bulletBody->setGravityEnable(false);
	bullet->setPhysicsBody(bulletBody);
	this->addChild(bullet);
	this->bulletList.pushBack(bullet);
}
//让子弹飞
void GameScene::objectMove(float f)
{
	//遍历vector取出所有的子弹，让子弹的位置往上移，水往低处流，子弹向上飞嘛
	for(int i = 0; i < bulletList.size() ; i++)
	{ 
		auto bullet = bulletList.at(i);
		bullet->setPositionY(bullet->getPositionY()+3);
		//如果该子弹已经超出屏幕范围，则移除它
		if(bullet->getPositionY()>Director::getInstance()->getWinSize().height)
		{
			bullet->removeFromParent();		//从层中移除
			bulletList.eraseObject(bullet);	//从记录所有子弹的vector中移除
			//移除后上一个对象会移到当前这个对象的位置，实际还是当前这个i，所以要i--才能访问到下一个对象
			i--;
		}
	}

	//取出所有的敌机，让敌机往下移动
	for(int i = 0; i < enemyList.size() ; i++)
	{ 
		auto enemy = enemyList.at(i);
		enemy->setPositionY(enemy->getPositionY()-5);
		//如果该子弹已经超出屏幕范围，则移除它
		if(enemy->getPositionY() < -enemy->getContentSize().height)
		{
			enemy->removeFromParent();		//从层中移除
			enemyList.eraseObject(enemy);	//从记录所有子弹的vector中移除
			//移除后上一个对象会移到当前这个对象的位置，实际还是当前这个i，所以要i--才能访问到下一个对象
			i--;
		}
	}
}
//敌机创建
void GameScene::enemyCreate(float f)
{
	//随机出现敌机1或敌机2
	int ranDom = rand()%2+1;
	auto string = cocos2d::__String::createWithFormat("enemy%d.png",ranDom);
	auto enemy = Sprite::create(string->getCString()); 
	if(ranDom == 1)
	{
		enemy->setTag(104);		//敌机的类型，由这个来判断，用于分数计算
	}
	else
	{
		enemy->setTag(105);
	}
	
	enemy->setPosition(Vec2(rand()%(int)(Director::getInstance()->getVisibleSize().width),Director::getInstance()->getVisibleSize().height+enemy->getContentSize().height));		//随机在屏幕最上方的出现敌机
	auto enemyBody = PhysicsBody::createBox(enemy->getContentSize());
	enemyBody->setContactTestBitmask(0x0003);
	enemyBody->setCategoryBitmask(0x0002);
	enemyBody->setCollisionBitmask(0x0001);
	enemyBody->setGravityEnable(false);
	enemy->setPhysicsBody(enemyBody);
	this->addChild(enemy);
	this->enemyList.pushBack(enemy);
}
//飞机爆动画
void GameScene::planeBomb(Vec2 vec,int tag)//爆炸效果
{
	float timeDelay = 0.1;
	Vector<SpriteFrame*> animationframe;
	if(tag == 104)		//小敌机动画帧
	{
		for(int i=1;i<5;i++)
		{
			auto string = cocos2d::__String::createWithFormat("enemy1_down%d.png",i);
			SpriteFrame * sf=SpriteFrame::create(string->getCString(),Rect(0,0,57,43));
			animationframe.pushBack(sf);
		}
	}
	else if(tag == 105)
	{
		 for(int i=1;i<5;i++)
		{
			auto string = cocos2d::__String::createWithFormat("enemy2_down%d.png",i);
			SpriteFrame * sf=SpriteFrame::create(string->getCString(),Rect(0,0,69,95));
			animationframe.pushBack(sf);
		}
	}
	else
	{
		timeDelay = 0.5;
		 for(int i=1;i<5;i++)
		{
			auto string = cocos2d::__String::createWithFormat("hero_blowup_n%d.png",i);
			SpriteFrame * sf=SpriteFrame::create(string->getCString(),Rect(0,0,102,126));
			animationframe.pushBack(sf);
		}
	}
	Animation * ani=Animation::createWithSpriteFrames(animationframe,timeDelay);
	auto blanksprite=Sprite::create();
	blanksprite->setTag(tag);
	Action * act=Sequence::create(Animate::create(ani),CCCallFuncN::create(blanksprite,callfuncN_selector(GameScene::bombRemove)),NULL);
	this->addChild(blanksprite);
	blanksprite->setPosition(vec);
	blanksprite->runAction(act);
	
}
void GameScene::bombRemove(Node * sprite)//删除自己
{
	sprite->removeFromParentAndCleanup(true);
	if (sprite->getTag() == 103) 
	{
		SimpleAudioEngine::getInstance()->stopBackgroundMusic("sounds/game_music.wav");
		//游戏结束
		gameOver();
	}
}
//停止所有的定时器
void GameScene::stopAllSchedule()
{
	this->unscheduleAllSelectors();
}
//游戏结束
void GameScene::gameOver()
{
	
}