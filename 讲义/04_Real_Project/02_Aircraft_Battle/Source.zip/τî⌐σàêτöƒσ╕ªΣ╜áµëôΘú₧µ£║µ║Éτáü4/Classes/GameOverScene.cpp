﻿#include "GameOverScene.h"
#include "GameScene.h"

USING_NS_CC;

Scene* GameOverScene::createScene()
{
	auto scene = Scene::create();
	auto layer = GameOverScene::create();
	scene->addChild(layer);

	return scene;
}
bool GameOverScene::init()
{
	if ( !Layer::init() )
	{
		return false;
	}

	Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

	//创建背景
    auto bg = Sprite::create("gameover.png");
	bg->setPosition(Vec2(origin.x + visibleSize.width/2,visibleSize.height/2));
	bg->setAnchorPoint(Vec2(0.5,0.5));
    this->addChild(bg,0);
	 
	int currentScore = UserDefault::getInstance()->getIntegerForKey("currentScore");
	int topScore = UserDefault::getInstance()->getIntegerForKey("topScore");
	//显示最终分数
	auto label = cocos2d::Label::createWithSystemFont(__String::createWithFormat("%d",currentScore)->getCString(),"Arial",24);
	label->setPosition(Vec2(visibleSize.width/2, origin.y + visibleSize.height/2 + 60));
	label->setHorizontalAlignment(kCCTextAlignmentRight);
	label->setAnchorPoint(Vec2(0.5,0.5));
    this->addChild(label, 1);
	//显示最高分数
	auto label2 = cocos2d::Label::createWithSystemFont(__String::createWithFormat("%d",topScore)->getCString(),"Arial",24);
	label2->setPosition(Vec2(visibleSize.width/2, origin.y + visibleSize.height-label2->getContentSize().height));
	label2->setHorizontalAlignment(kCCTextAlignmentRight);
	label2->setAnchorPoint(Vec2(0.5,0.5));
    this->addChild(label2, 1);
	  
	//继续游戏菜单项 
	auto startItem = MenuItemImage::create( "game_start.png", "game_start2.png", CC_CALLBACK_1(GameOverScene::continueGame,this));
    startItem->setPosition(Vec2(visibleSize.width/2 + origin.x, visibleSize.height/2 + origin.y));
	//退出游戏菜单项
	auto closeItem = MenuItemImage::create( "game_exit.png", "game_exit2.png",CC_CALLBACK_1(GameOverScene::exitGame, this));
    closeItem->setPosition(Vec2(origin.x + visibleSize.width/2 ,visibleSize.height/2 + origin.y - startItem->getContentSize().height));
    //把菜单项添加到菜单精灵中
	auto menu = Menu::create(startItem,closeItem, NULL);
    menu->setPosition(Vec2::ZERO);
	//把菜单精灵添加到当前的层中
    this->addChild(menu,1);
	

	return true;
}
//继续游戏菜单项的回调函数
void GameOverScene::continueGame(Ref* pSender)
{
	auto scene = GameScene::createScene();
	auto gameScene = TransitionSlideInR::create(1.0f,scene);
	Director::getInstance()->replaceScene(gameScene);
}

void GameOverScene::exitGame(Ref* pSender)
{
	#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.","Alert");
    return;
#endif

    Director::getInstance()->end();			//退出

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}